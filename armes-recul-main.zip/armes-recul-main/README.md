Hey !

# Français

1) Glisser le fichier dans votre base.
2) Ajouter "ensure armes-recul" dans votre server.cfg

# English

1) Drag the file into your database.
2) Add "ensure armes-recul" in your server.cfg.

# The resource author is Haontes
Discord: haøntes#0001