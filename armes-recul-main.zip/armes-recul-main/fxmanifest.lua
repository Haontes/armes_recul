fx_version 'adamant'
games { 'rdr3', 'gta5' }
author "jamsou"

files {
  "weapons.meta",
}

data_file "WEAPONINFO_FILE_PATCH" "weapons.meta"
